from time import sleep
from collections import defaultdict
import requests

base_url = "https://68ecj67379.execute-api.ap-northeast-2.amazonaws.com/api"
x_auth_token = "bc8ceab4868352ed7647c0e41657ec0d"


# 시나리오 번호에 맞게 모든 유저 정보 초기화
# num : 시나리오 번호
def start_api(num: int):
    url = base_url + "/start"
    headers = {'X-Auth-Token': x_auth_token}
    data = {"problem": num}
    response = requests.post(url, headers=headers, json=data).json()
    return response["auth_key"]

# 현재 날짜에 새로 들어온 예약 요청의 정보를 반환합니다.
# return: 각 예약 요청의 id, 객실 수, 체크인 날짜, 체크아웃 날짜를 담은 배열
# id	            Integer	예약 요청 id
# amount	        Integer	객실 수
# check_in_date	    Integer	체크인 날짜
# check_out_date	Integer	체크아웃 날짜
def api_new_requests(auth_key):
    url = base_url + "/new_requests"
    headers = {'Authorization': auth_key}
    response = requests.get(url, headers=headers).json()
    return response["reservations_info"]


# 특정 예약 요청에 대한 승낙 / 거절을 답변합니다.
# rep_list : list
# { "id": 412424, "reply": "accepted"},
# { "id": 707981, "reply": "refused"},
# return : 현재 날짜
def api_reply(auth_key, rep_list):
    url = base_url + "/reply"
    headers = {'Authorization': auth_key}
    data = {"replies": rep_list}
    response = requests.put(url, headers=headers, json=data).json()
    return response


# 오늘 호텔에 체크인 하려는 손님들에게 객실 번호를 배정해 서버에 전달하고 1일이 진행됩니다.
# 현재 날짜가 (시나리오의 최대 날짜)일 때 api를 호출하면 시뮬레이션이 종료됩니다.
# id	        Integer	예약 요청의 id
# room_number	Integer	배정할 객실 번호
def api_simulate(auth_key, room_assign):
    url = base_url + "/simulate"
    headers = {'Authorization': auth_key}
    data = {"room_assign": room_assign}
    response = requests.put(url, headers=headers, json=data).json()
    # print(response)
    return response


# 해당 Auth key로 획득한 점수를 반환합니다.
def api_score(auth_key):
    url = base_url + "/score"
    headers = {'Authorization': auth_key}
    response = requests.get(url, headers=headers).json()
    return response


# 해당 기간에 객실 사용이 가능한 지 반환
def check_accept_room(check_in_date, check_out_date, floor, room_num, room_info):
    for date in range(check_in_date, check_out_date):
        if room_info[date][floor][room_num] == 1:
            return False
    return True


# 해당 예약 정보 객실 배정이 가능한 시작 방 번호 리스트 반환
def check_accept_reservation(reservation_info, room_info, scenario):
    max_floor, max_room_num = 3, 20
    if scenario == 2:
        max_floor, max_room_num = 10, 200
    res_id, amount, check_in_date, check_out_date = reservation_info
    acceptable_room_number = []
    for floor in range(1, max_floor+1):
        room_count = 0
        for room_num in range(1, max_room_num+1):
            if check_accept_room(check_in_date, check_out_date, floor, room_num, room_info):
                room_count += 1
                if room_count >= amount:
                    acceptable_room_number.append(floor*1000+room_num-amount+1)
            else:
                room_count = 0
    return acceptable_room_number

# 제일 남은 객실이 가장 적은 층의 방 번호 반환
def best_room_number(reservation_info, room_info, acceptable_room_number):
    room_len = len(room_info[0][0])
    min_floor_num = 1001
    min_floor = 0
    min_room_number = 10201
    check_in_date = reservation_info[2]
    for room in acceptable_room_number:
        floor, room_num = room // 1000, room % 1000
        left_room = room_len - sum(room_info[check_in_date][floor])
        if left_room <= min_floor_num:
            min_floor_num = left_room
            if min_floor == floor:
                if room < min_room_number:
                    min_room_number = room
            else:
                min_floor = floor
                min_room_number = room
    return min_room_number


# 방 정보 업데이트
def update_room_info(reservation_info, room_info, best_room):
    res_id, amount, check_in_date, check_out_date = reservation_info
    floor, room_num = best_room // 1000, best_room % 1000
    for date in range(check_in_date, check_out_date):
        # debug
        if room_info[date][floor][room_num] == 1:
            print("update_room_info error!")
        for i in range(room_num, room_num+amount):
            room_info[date][floor][i] = 1

# 예약 리스트 방 개수로 정렬
def sort_reservations_dict(reservations_dict):
    res_list = list(reservations_dict.values())
    res_list.sort(key=lambda x:((x[1] * (x[2]-x[3])), x[1], x[2]-x[3], x[2], x[3]))
    return res_list

# 들어온 요청 중 가능한 요청 전부 승낙
# 승낙한 요청 방 정보 업데이트
# return ->  승낙한 예약번호와 방 정보 리스트
def reservation_reply(auth_key, reservations_dict, reservations_left_time, room_info, scenario):
    reply_result = []
    accept_reservation_info = []
    reservations_list = sort_reservations_dict(reservations_dict)

    # 예약 거절조건 추가
    pivot = 0
    if scenario == 2:
        pivot = 3

    for res_info in reservations_list:
        res_id = res_info[0]
        room_list = check_accept_reservation(res_info, room_info, scenario)

        # 요청 승낙 거절 판단
        if res_info[1] >= pivot and len(room_list):
            best_room = best_room_number(res_info, room_info, room_list)
            reply_result.append({"id": res_id, "reply": "accepted"})
            update_room_info(res_info, room_info, best_room)
            accept_reservation_info.append((res_info, best_room))
            del reservations_dict[res_id]
            del reservations_left_time[res_id]
        elif reservations_left_time[res_id] == 0:
            reply_result.append({"id": res_id, "reply": "refused"})
            del reservations_dict[res_id]
            del reservations_left_time[res_id]
        else:
            continue
    api_reply(auth_key, reply_result)
    return accept_reservation_info

# 요청 응답 남은 시간 업데이트
def update_reservations_left_time(reservations_list, reservations_left_time):
    key_list = list(reservations_left_time.keys())
    for res_id in key_list:
        reservations_left_time[res_id] -= 1
        if reservations_left_time[res_id] == 0:
            del reservations_left_time[res_id]
            del reservations_list[res_id]

# 현재 날짜에 새로 들어온 예약 요청 정보 반환
# return =  id : (id, amount, check_in_date, check_out_date)
def today_new_requests(auth_key, reservations, reservations_left_time, date):
    raw_reservations_list = api_new_requests(auth_key)
    for info in raw_reservations_list:
        reservations[info["id"]] = (info["id"], info["amount"], info["check_in_date"], info["check_out_date"])
        reservations_left_time[info["id"]] = min(date + 14, info["check_in_date"]-1)


# 승낙한 예약 정보 테이블 업데이트
def update_reservation_dict(reservations_list, reservation_table, accept_reservation_info):
    for res_info, room in accept_reservation_info:
        # reservation_table에 해당 예약 정보, 방번호 추가
        check_in_date = res_info[2]
        reservation_table[check_in_date].append((res_info, room))


# 객실 배정
def select_room(date, reservation_table):
    res = []
    for reservation_info, room in reservation_table[date]:
        res.append({"id": reservation_info[0], "room_number": room})
    api_simulate(auth_key, res)


# main
scenario = 2
auth_key = start_api(scenario)

max_floor, max_room_num, max_date = 3, 20, 200
if scenario == 2:
    max_floor, max_room_num, max_date = 10, 200, 1000

# 예약 처리 대기중인 요청들
reservations_list = {}

# 예약 처리 대기중인 요청의 남은 기한
reservations_left_time = {}

# 날짜별 예약정보가 담긴 테이블
reservation_table = defaultdict(list)
room_info = [[[0] * (max_room_num+1) for _ in range(max_floor+1)] for _ in range(max_date+1)]

for date in range(1, max_date+1):
    print("date", date)
    for i in range(1, max_floor+1):
        print(room_info[date][i])
    print(reservations_list)
    print(reservations_left_time)

    # 요청 남은 기한 갱신
    update_reservations_left_time(reservations_list, reservations_left_time)
    # 오늘 새로 들어온 예약 요청 추가
    today_new_requests(auth_key, reservations_list, reservations_left_time, date)
    # print(reservations_list)
    accept_reservation_info = reservation_reply(auth_key, reservations_list, reservations_left_time, room_info, scenario)
    update_reservation_dict(reservations_list, reservation_table, accept_reservation_info)
    select_room(date, reservation_table)
    if date % 3 == 0:
        sleep(1)
print(api_score(auth_key))
